DROP TABLE IF EXISTS asm_mt_weight;
CREATE TABLE asm_mt_weight (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `weight` varchar(250) NOT NULL,
  `type` varchar(250) NOT NULL,
  `status` int(2) NOT NULL,
  `create_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  CONSTRAINT asm_mt_weight_pk PRIMARY KEY (`id`),
  CONSTRAINT asm_mt_weight_weight_u UNIQUE (`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;