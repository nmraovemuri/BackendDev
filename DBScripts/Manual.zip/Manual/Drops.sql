DROP TABLE IF EXISTS asm_admin;
DROP TABLE IF EXISTS asm_mt_category;
DROP TABLE IF EXISTS asm_mt_subcategory;
DROP TABLE IF EXISTS asm_mt_weight;
DROP TABLE IF EXISTS asm_products;
DROP TABLE IF EXISTS asm_product_weight_price;
DROP TABLE IF EXISTS asm_product_cat_subcat;
DROP TABLE IF EXISTS asm_product_stock;

DROP DATABASE IF EXISTS asm_service; 
