DROP TABLE IF EXISTS asm_product_weight_price;

CREATE TABLE asm_product_weight_price (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `product_id` int(25) NOT NULL,
  `price` bigint(55) NOT NULL,
  `weight_id` int(25) NOT NULL,
  `stock_status` int(11) NOT NULL,
  `offer` bigint(55) NOT NULL,
  `status` int(2) NOT NULL,
  `create_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  CONSTRAINT asm_product_weight_price_pk PRIMARY KEY (`id`),
  CONSTRAINT asm_product_weight_price_product_id_fk FOREIGN KEY (product_id) REFERENCES asm_products (`id`),
  CONSTRAINT asm_product_weight_price_weight_id_fk  FOREIGN KEY (weight_id)  REFERENCES asm_mt_weight (`id`)

) ENGINE=InnoDB DEFAULT CHARSET=latin1;
